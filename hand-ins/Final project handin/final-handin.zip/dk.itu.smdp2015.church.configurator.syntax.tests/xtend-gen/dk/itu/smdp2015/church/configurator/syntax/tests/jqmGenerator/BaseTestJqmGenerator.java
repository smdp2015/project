package dk.itu.smdp2015.church.configurator.syntax.tests.jqmGenerator;

import dk.itu.smdp2015.church.configurator.syntax.tests.BaseXtextTest;

@SuppressWarnings("all")
public abstract class BaseTestJqmGenerator extends BaseXtextTest {
}
