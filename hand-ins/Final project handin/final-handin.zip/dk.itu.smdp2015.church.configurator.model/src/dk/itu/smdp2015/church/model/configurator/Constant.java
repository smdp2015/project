/**
 */
package dk.itu.smdp2015.church.model.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Constant</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dk.itu.smdp2015.church.model.configurator.ConfiguratorPackage#getConstant()
 * @model abstract="true"
 * @generated
 */
public interface Constant extends Expression {
} // Constant
