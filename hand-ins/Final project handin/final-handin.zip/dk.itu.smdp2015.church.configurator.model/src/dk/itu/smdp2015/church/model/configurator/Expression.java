/**
 */
package dk.itu.smdp2015.church.model.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dk.itu.smdp2015.church.model.configurator.ConfiguratorPackage#getExpression()
 * @model abstract="true"
 * @generated
 */
public interface Expression extends EObject {
} // Expression
