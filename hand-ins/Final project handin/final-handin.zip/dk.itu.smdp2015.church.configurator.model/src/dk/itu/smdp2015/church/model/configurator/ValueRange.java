/**
 */
package dk.itu.smdp2015.church.model.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Value Range</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dk.itu.smdp2015.church.model.configurator.ConfiguratorPackage#getValueRange()
 * @model abstract="true"
 * @generated
 */
public interface ValueRange extends EObject {

} // ValueRange
