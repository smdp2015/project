package dk.itu.smdp2015.church.xtext.common;

@SuppressWarnings("all")
public enum ExpressionType {
  String,
  
  Integer,
  
  Boolean;
}
